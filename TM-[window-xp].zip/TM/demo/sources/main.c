#include <stdio.h>
#include <stdbool.h>
#include <windows.h>
#include <Num.h>


#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480





int PaintRectangle(SHORT left, SHORT top, USHORT width, USHORT height, COLORREF color, HDC hDstDC);

LRESULT WINAPI MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);



int main()
{
    int a = addNum(5,5);
    printf("%d", a);

    HINSTANCE hInstance = GetModuleHandle(0);

    MSG msg;
    WNDCLASS wc;

    HWND hWnd;
    HBITMAP LP__Backbuffer;
    HDC hWndDC;
    HDC hBackbufferDC;

    int left = 0, top = 0;
    USHORT width = 32, height = 24;
    COLORREF color = RGB(255, 255, 255);

    wc.lpszClassName = "MainWindowClass";
    wc.lpfnWndProc = MainWndProc;

    wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszMenuName = NULL;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;

    if (RegisterClass(&wc) == 0)
    {
        MessageBox(NULL, "RegisterClass failed.", "Double buffering", MB_ICONERROR);
        return 0;
    }

    hWnd = CreateWindow("MainWindowClass",
                        "Double buffering",
                        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                        0,
                        0,
                        WINDOW_WIDTH,
                        WINDOW_HEIGHT,
                        NULL,
                        NULL,
                        hInstance,
                        NULL);


    if (hWnd == NULL)
    {
        MessageBox(NULL, "CreateWindow failed.", "Double buffering", MB_ICONERROR);
        return 0;
    }


    hWndDC = GetDC(hWnd);
    LP__Backbuffer = CreateCompatibleBitmap(hWndDC, WINDOW_WIDTH, WINDOW_HEIGHT);
    hBackbufferDC = CreateCompatibleDC(hWndDC);
    SelectObject(hBackbufferDC, LP__Backbuffer);


    while (true)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            if (msg.message == WM_QUIT)
                break;
            DispatchMessage(&msg);
        }
        else
        {

            if (left >= WINDOW_WIDTH)
            {

                color = RGB(rand() % 255, rand() % 255, rand() % 255);
                width = rand() % WINDOW_WIDTH;
                height = rand() % WINDOW_HEIGHT;
                left = -width;
                top = rand() % (WINDOW_HEIGHT - height);
            }
            else
            {
                left += 2;
            }

            PaintRectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, 0, hBackbufferDC);
            PaintRectangle(left, top, width, height, color, hBackbufferDC);
            BitBlt(hWndDC, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, hBackbufferDC, 0, 0, SRCCOPY);


            hWndDC = GetDC(hWnd);
            LP__Backbuffer = CreateCompatibleBitmap(hWndDC, WINDOW_WIDTH, WINDOW_HEIGHT);
            hBackbufferDC = CreateCompatibleDC(hWndDC);
            SelectObject(hBackbufferDC, LP__Backbuffer);


            UpdateWindow(hWnd);
            ShowWindow(hWnd, SW_SHOW);
            Sleep(1000/60);
        }
    }


    ReleaseDC(hWnd, hWndDC);
    DeleteDC(hBackbufferDC);
    DeleteObject(LP__Backbuffer);


    return msg.wParam;
}

LRESULT WINAPI MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_CLOSE:
            DestroyWindow(hWnd);
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int PaintRectangle(SHORT left, SHORT top, USHORT width, USHORT height, COLORREF color, HDC hDstDC) {
    if (hDstDC == NULL)
        return -1;
    int returnValue;
    RECT rect = { left, top, left + width, top + height };
    HBRUSH hBrush;
    hBrush = CreateSolidBrush(color);
    returnValue = FillRect(hDstDC, &rect, hBrush);
    DeleteObject(hBrush);
    return returnValue;
}