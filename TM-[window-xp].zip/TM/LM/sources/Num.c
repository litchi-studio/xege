
#include "Num.h"



int addNum(int i, int s) {
    return i + s;
}