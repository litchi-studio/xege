//
// Created by beanflame - 2021/7/25
//


#ifndef TEST_X_H
#define TEST_X_H


int addNum(int i, int s);

#endif //TEST_X_H















